-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:8889
-- Время создания: Июл 31 2024 г., 12:04
-- Версия сервера: 5.7.39
-- Версия PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `my_project`
--

-- --------------------------------------------------------

--
-- Структура таблицы `all_users`
--

CREATE TABLE `all_users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `vk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telegram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `all_users`
--

INSERT INTO `all_users` (`id`, `username`, `job_title`, `status`, `image`, `phone`, `address`, `email`, `vk`, `telegram`, `instagram`) VALUES
(1, 'Zelenkov Sergey Petrovich', 'IT Director, Gotbootstrap Inc.', 'offline', 'avatar-b.png', '+79009966936', '182330, Pskov city, Opochka town', 'u900em@rambler.ru', 'vk.com', 'telegram.org', 'instagram.com'),
(2, 'Nikiforova Elena Andreevna', 'Project Manager, Bootstrap Inc.', 'success', 'avatar-a.png', '+1 313-461-1340', '134 Hamtrammac, Detroit, MI, 48314, USA', 'n092nn@mail.ru', 'vk.com', 'telegram.org', 'instagram.com'),
(117, 'Zelenkova Natalia', 'Veterinarnaia klinika', 'danger', '658accafb8501.png', '+ 7 921 324 74 00', 'SPB, Kolpino, Lenina 1-12', 'm700eu@mail.ru', '', '', ''),
(118, 'Petr Vasiliev', 'QI/QX дизайнер', 'success', '66aa240a67d89.png', '89116663300', 'Pskov, Lenina 6-3', 'm700eu@mail.com', '', '', '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `role`) VALUES
(1, 'u900em@rambler.ru', '$2y$10$/cXuTB.vnQjrxyEDwdAJl.HSGWPCkk3vO6yTBuGRpFw.Wg9.CgmJW', 'admin'),
(2, 'n092nn@mail.ru', '$2y$10$QfRXoo3.hei7rbRqb41SceVf7nSFnXjbqR1P/6CDYOACgtcUeg.KW', 'user'),
(117, 'm700eu@mail.ru', '$2y$10$19YnDnAjE/ImaH65hpSaj.RnxKeXbEPcj65xV7P7HlG.CudD8i/mi', 'user'),
(118, 'm700eu@mail.com', '$2y$10$LHpnf/FIXn.kqLHMP1N33OEhqPoxDnDvO7HYAeI3IwgXGkixH8b7K', 'user');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `all_users`
--
ALTER TABLE `all_users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `all_users`
--
ALTER TABLE `all_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
